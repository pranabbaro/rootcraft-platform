# RootCraft Static V1

A complete serverless RootCraft Academy website built with only HTML, CSS and JavaScript.

## No server required

You do not need:

- Node.js
- npm
- Next.js
- A database
- A backend server

## Run locally

Open `index.html` directly in Microsoft Edge, or use VS Code Live Server.

## Publish to GitHub Pages

Copy all files into your GitHub repository, then run:

```bash
git add .
git commit -m "Add RootCraft Static V1"
git push origin main
```

In GitHub:

`Settings → Pages → Deploy from a branch → main → /(root)`

## Included

- Premium RootCraft homepage
- About and programs
- Expanded Kannada lessons
- Vowels and consonants
- Numbers
- Animals, fruits, vegetables, birds
- Colours, family, body parts, shapes and weekdays
- Picture quiz
- Memory game
- Stories
- Browser voice support
- Local progress tracking
- Stars and rewards
- Search
- Dark mode
- PWA/offline support

## Important voice note

The browser voice feature uses the device's installed voices. If a Kannada voice is unavailable, it speaks the English meaning instead.

## Customization

Search for and update:

- `hello@rootcraft.in`
- `India`
- RootCraft Academy text


## Multilingual update

This package preserves the original RootCraft design and layout.

Only multilingual learning support was added:

- Kannada
- English
- Hindi
- The same lesson cards, quiz, memory game and story layout
- Separate progress for each language
- A language selector added inside the existing learning toolbar
- No server, Node.js or npm required

The old service worker was removed to prevent outdated language data from remaining cached.


## Header language selector update

- Removed the `Kannada Learning` navigation tab.
- Moved the Kannada / English / Hindi dropdown into the same header position.
- Removed the duplicate dropdown from the learning toolbar.
- Kept the existing design, layout, sections and content unchanged.


## Dual language selector update

- Header language selector retained.
- Learning-section language selector restored.
- Both selectors stay synchronized.
- Changing either selector updates the same multilingual content.
- Existing design, colours, layout, cards and sections remain unchanged.
