const DATA={
kannada:{label:"Kannada",subtitle:"ಕನ್ನಡ ಕಲಿಯಿರಿ",topics:{
letters:{title:"Vowels",icon:"ಅ",items:[["🌟","ಅ","A","ಅ ಅಕ್ಷರ"],["🌈","ಆ","Aa","ಆನೆ ದೊಡ್ಡದು."],["✨","ಇ","I","ಇದು ಮನೆ."],["🦅","ಈ","Ee","ಈ ಹಕ್ಕಿ."],["🌼","ಉ","U","ಉಡುಪಿ ನಗರ."],["🎈","ಊ","Oo","ಊಟ ಮಾಡು."],["🍀","ಎ","E","ಎಲೆ ಹಸಿರು."],["🌞","ಏ","Ae","ಏಣಿ ಉದ್ದವಾಗಿದೆ."]]},
numbers:{title:"Numbers",icon:"೧೨೩",items:[["1️⃣","ಒಂದು","One","ಒಂದು ಸೇಬು."],["2️⃣","ಎರಡು","Two","ಎರಡು ಹಕ್ಕಿಗಳು."],["3️⃣","ಮೂರು","Three","ಮೂರು ಚೆಂಡುಗಳು."],["4️⃣","ನಾಲ್ಕು","Four","ನಾಲ್ಕು ಹೂಗಳು."],["5️⃣","ಐದು","Five","ಐದು ಮಾವುಗಳು."],["6️⃣","ಆರು","Six","ಆರು ಪುಸ್ತಕಗಳು."]]},
animals:{title:"Animals",icon:"🐘",items:[["🐘","ಆನೆ","Elephant","ಆನೆ ದೊಡ್ಡ ಪ್ರಾಣಿ."],["🐶","ನಾಯಿ","Dog","ನಾಯಿ ಒಳ್ಳೆಯ ಸ್ನೇಹಿತ."],["🐱","ಬೆಕ್ಕು","Cat","ಬೆಕ್ಕು ಹಾಲು ಕುಡಿಯುತ್ತದೆ."],["🐄","ಹಸು","Cow","ಹಸು ಹಾಲು ಕೊಡುತ್ತದೆ."],["🐯","ಹುಲಿ","Tiger","ಹುಲಿ ಕಾಡಿನಲ್ಲಿ ವಾಸಿಸುತ್ತದೆ."],["🦁","ಸಿಂಹ","Lion","ಸಿಂಹ ಬಲವಾದ ಪ್ರಾಣಿ."]]},
fruits:{title:"Fruits",icon:"🥭",items:[["🥭","ಮಾವು","Mango","ಮಾವು ಸಿಹಿ ಹಣ್ಣು."],["🍎","ಸೇಬು","Apple","ಸೇಬು ಕೆಂಪಾಗಿದೆ."],["🍌","ಬಾಳೆಹಣ್ಣು","Banana","ಬಾಳೆಹಣ್ಣು ಹಳದಿ."],["🍊","ಕಿತ್ತಳೆ","Orange","ಕಿತ್ತಳೆ ರಸ ಸಿಹಿ."],["🍇","ದ್ರಾಕ್ಷಿ","Grapes","ದ್ರಾಕ್ಷಿ ಗುಚ್ಛವಾಗಿ ಬೆಳೆಯುತ್ತದೆ."],["🍉","ಕಲ್ಲಂಗಡಿ","Watermelon","ಕಲ್ಲಂಗಡಿ ದೊಡ್ಡ ಹಣ್ಣು."]]},
colors:{title:"Colours",icon:"🎨",items:[["🔴","ಕೆಂಪು","Red","ಗುಲಾಬಿ ಕೆಂಪಾಗಿದೆ."],["🔵","ನೀಲಿ","Blue","ಆಕಾಶ ನೀಲಿ."],["🟢","ಹಸಿರು","Green","ಎಲೆ ಹಸಿರು."],["🟡","ಹಳದಿ","Yellow","ಸೂರ್ಯ ಹಳದಿ."],["⚫","ಕಪ್ಪು","Black","ಕಾಗೆ ಕಪ್ಪು."],["⚪","ಬಿಳಿ","White","ಹಾಲು ಬಿಳಿ."]]},
family:{title:"Family",icon:"👨‍👩‍👧",items:[["👩","ಅಮ್ಮ","Mother","ಅಮ್ಮ ನನ್ನನ್ನು ಪ್ರೀತಿಸುತ್ತಾರೆ."],["👨","ಅಪ್ಪ","Father","ಅಪ್ಪ ನನ್ನ ಜೊತೆ ಆಟ ಆಡುತ್ತಾರೆ."],["👵","ಅಜ್ಜಿ","Grandmother","ಅಜ್ಜಿ ಕಥೆ ಹೇಳುತ್ತಾರೆ."],["👴","ತಾತ","Grandfather","ತಾತ ನಡೆಯುತ್ತಾರೆ."]]}
}},
english:{label:"English",subtitle:"Alphabet, phonics and words",topics:{
alphabet:{title:"Alphabet",icon:"ABC",items:[["🍎","A","Apple","A is for Apple."],["⚽","B","Ball","B is for Ball."],["🐱","C","Cat","C is for Cat."],["🐶","D","Dog","D is for Dog."],["🥚","E","Egg","E is for Egg."],["🐟","F","Fish","F is for Fish."],["🍇","G","Grapes","G is for Grapes."],["🏠","H","House","H is for House."]]},
phonics:{title:"Phonics",icon:"🔊",items:[["🍎","A","/æ/","Apple begins with the A sound."],["⚽","B","/b/","Ball begins with the B sound."],["🐱","C","/k/","Cat begins with the C sound."],["🐶","D","/d/","Dog begins with the D sound."],["🐟","F","/f/","Fish begins with the F sound."],["🌞","S","/s/","Sun begins with the S sound."]]},
numbers:{title:"Numbers",icon:"123",items:[["1️⃣","One","1","One apple."],["2️⃣","Two","2","Two birds."],["3️⃣","Three","3","Three balls."],["4️⃣","Four","4","Four flowers."],["5️⃣","Five","5","Five mangoes."],["6️⃣","Six","6","Six books."]]},
animals:{title:"Animals",icon:"🐘",items:[["🐘","Elephant","ಆನೆ","The elephant is big."],["🐶","Dog","ನಾಯಿ","The dog is friendly."],["🐱","Cat","ಬೆಕ್ಕು","The cat drinks milk."],["🐄","Cow","ಹಸು","The cow gives milk."],["🐯","Tiger","ಹುಲಿ","The tiger lives in the forest."],["🦁","Lion","ಸಿಂಹ","The lion is strong."]]},
fruits:{title:"Fruits",icon:"🍎",items:[["🥭","Mango","ಮಾವು","The mango is sweet."],["🍎","Apple","ಸೇಬು","The apple is red."],["🍌","Banana","ಬಾಳೆಹಣ್ಣು","The banana is yellow."],["🍊","Orange","ಕಿತ್ತಳೆ","The orange is juicy."],["🍇","Grapes","ದ್ರಾಕ್ಷಿ","Grapes grow in bunches."],["🍉","Watermelon","ಕಲ್ಲಂಗಡಿ","The watermelon is big."]]},
colors:{title:"Colours",icon:"🌈",items:[["🔴","Red","ಕೆಂಪು","The rose is red."],["🔵","Blue","ನೀಲಿ","The sky is blue."],["🟢","Green","ಹಸಿರು","The leaf is green."],["🟡","Yellow","ಹಳದಿ","The sun is yellow."],["⚫","Black","ಕಪ್ಪು","The crow is black."],["⚪","White","ಬಿಳಿ","Milk is white."]]}
}},
hindi:{label:"Hindi",subtitle:"हिंदी सीखें",topics:{
vowels:{title:"स्वर",icon:"अ",items:[["🍎","अ","A","अ से अनार।"],["🥭","आ","Aa","आ से आम।"],["🏠","इ","I","इ से इमली।"],["🦅","ई","Ee","ई से ईख।"],["🦉","उ","U","उ से उल्लू।"],["ऊन","ऊ","Oo","ऊ से ऊन।"],["एक","ए","E","ए से एक।"],["ऐनक","ऐ","Ai","ऐ से ऐनक।"]]},
numbers:{title:"संख्याएँ",icon:"१२३",items:[["1️⃣","एक","One","एक सेब।"],["2️⃣","दो","Two","दो पक्षी।"],["3️⃣","तीन","Three","तीन गेंदें।"],["4️⃣","चार","Four","चार फूल।"],["5️⃣","पाँच","Five","पाँच आम।"],["6️⃣","छह","Six","छह किताबें।"]]},
animals:{title:"जानवर",icon:"🐘",items:[["🐘","हाथी","Elephant","हाथी बड़ा जानवर है।"],["🐶","कुत्ता","Dog","कुत्ता अच्छा मित्र है।"],["🐱","बिल्ली","Cat","बिल्ली दूध पीती है।"],["🐄","गाय","Cow","गाय दूध देती है।"],["🐯","बाघ","Tiger","बाघ जंगल में रहता है।"],["🦁","शेर","Lion","शेर शक्तिशाली है।"]]},
fruits:{title:"फल",icon:"🥭",items:[["🥭","आम","Mango","आम मीठा फल है।"],["🍎","सेब","Apple","सेब लाल है।"],["🍌","केला","Banana","केला पीला है।"],["🍊","संतरा","Orange","संतरा रसदार है।"],["🍇","अंगूर","Grapes","अंगूर गुच्छों में उगते हैं।"],["🍉","तरबूज","Watermelon","तरबूज बड़ा है।"]]},
colors:{title:"रंग",icon:"🎨",items:[["🔴","लाल","Red","गुलाब लाल है।"],["🔵","नीला","Blue","आसमान नीला है।"],["🟢","हरा","Green","पत्ता हरा है।"],["🟡","पीला","Yellow","सूरज पीला है।"],["⚫","काला","Black","कौआ काला है।"],["⚪","सफेद","White","दूध सफेद है।"]]},
family:{title:"परिवार",icon:"👨‍👩‍👧",items:[["👩","माँ","Mother","माँ मुझे प्यार करती हैं।"],["👨","पिता","Father","पिता मेरे साथ खेलते हैं।"],["👵","दादी","Grandmother","दादी कहानी सुनाती हैं।"],["👴","दादा","Grandfather","दादा सुबह चलते हैं।"]]}
}}};

const STORIES={
kannada:[["🐘","ದಯಾಳು ಆನೆ","ಒಂದು ಕಾಡಿನಲ್ಲಿ ದಯಾಳು ಆನೆ ವಾಸಿಸುತ್ತಿತ್ತು. ಒಂದು ದಿನ ಚಿಕ್ಕ ಹಕ್ಕಿಯ ಗೂಡು ಕೆಳಗೆ ಬಿತ್ತು. ಆನೆ ಗೂಡನ್ನು ಮರದ ಮೇಲೆ ಇಟ್ಟಿತು. ಪಾಠ: ಸಹಾಯ ಮಾಡುವುದು ನಿಜವಾದ ಬಲ."],["🌱","ಚಿಕ್ಕ ಬೀಜ","ಒಂದು ಚಿಕ್ಕ ಬೀಜ ಮಣ್ಣಿನೊಳಗೆ ಮಲಗಿತ್ತು. ಮಳೆ ಮತ್ತು ಸೂರ್ಯನ ಬೆಳಕಿನಿಂದ ಅದು ದೊಡ್ಡ ಗಿಡವಾಯಿತು. ಪಾಠ: ಸಣ್ಣ ಆರಂಭ ದೊಡ್ಡ ಬೆಳವಣಿಗೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ."]],
english:[["🐘","The Kind Elephant","A kind elephant lived in a forest. One day a little bird's nest fell down. The elephant placed it back on the tree. Moral: Helping others is true strength."],["🌱","The Little Seed","A tiny seed slept under the soil. Rain and sunshine helped it grow into a strong plant. Moral: Small beginnings can lead to great growth."]],
hindi:[["🐘","दयालु हाथी","एक जंगल में एक दयालु हाथी रहता था। एक दिन एक छोटी चिड़िया का घोंसला गिर गया। हाथी ने उसे पेड़ पर रख दिया। सीख: दूसरों की मदद करना सच्ची ताकत है।"],["🌱","छोटा बीज","एक छोटा बीज मिट्टी में सो रहा था। बारिश और धूप से वह एक मजबूत पौधा बन गया। सीख: छोटी शुरुआत बड़ी सफलता बन सकती है।"]]
};

let selectedLang=localStorage.getItem("rootcraftLang")||"kannada";
let progress=JSON.parse(localStorage.getItem("rootcraftMultiProgress")||'{"words":{},"stars":{},"best":{}}');
let voices=[],voice=null,currentQuiz=[],quizIndex=0,quizScore=0,first=null,lock=false,currentStory=null;

function ensure(){["kannada","english","hindi"].forEach(l=>{progress.words[l]??=0;progress.stars[l]??=0;progress.best[l]??=0})}
function save(){localStorage.setItem("rootcraftMultiProgress",JSON.stringify(progress));updateStats()}
function updateStats(){ensure();wordsStat.textContent=progress.words[selectedLang];starsStat.textContent=progress.stars[selectedLang];bestStat.textContent=progress.best[selectedLang];rewardSummary.textContent=`${progress.stars[selectedLang]} stars • ${progress.words[selectedLang]} words • Best quiz ${progress.best[selectedLang]}`}
function toast(m){toastEl.textContent=m;toastEl.classList.remove("hidden");setTimeout(()=>toastEl.classList.add("hidden"),2200)}
const toastEl=document.getElementById("toast");
function getLanguageCode(){
  return {
    kannada: "kn-IN",
    english: "en-IN",
    hindi: "hi-IN"
  }[selectedLang] || "en-IN";
}

function loadVoices(){
  if(!("speechSynthesis" in window)) return;
  voices = window.speechSynthesis.getVoices() || [];
  const target = getLanguageCode().toLowerCase();
  const shortCode = target.split("-")[0];

  voice =
    voices.find(v => v.lang.toLowerCase() === target) ||
    voices.find(v => v.lang.toLowerCase().startsWith(shortCode)) ||
    null;
}

function splitForSpeech(text){
  return String(text || "")
    .split(/(?<=[.!?।॥])\s+/)
    .map(part => part.trim())
    .filter(Boolean);
}

function speak(text, fallback){
  if(!("speechSynthesis" in window)){
    toast("Speech is not supported in this browser.");
    return;
  }

  window.speechSynthesis.cancel();
  loadVoices();

  const content = String(text || fallback || "").trim();
  if(!content){
    toast("No text is available to read.");
    return;
  }

  const chunks = splitForSpeech(content);
  let index = 0;

  function speakNext(){
    if(index >= chunks.length) return;

    const utterance = new SpeechSynthesisUtterance(chunks[index]);
    utterance.lang = getLanguageCode();
    utterance.rate = selectedLang === "english" ? 0.85 : 0.72;
    utterance.pitch = 1;
    utterance.volume = 1;
    if(voice) utterance.voice = voice;

    utterance.onend = () => {
      index += 1;
      speakNext();
    };

    utterance.onerror = () => {
      toast(
        selectedLang === "kannada"
          ? "Kannada voice is unavailable on this device."
          : selectedLang === "hindi"
          ? "Hindi voice is unavailable on this device."
          : "The browser could not play this speech."
      );
    };

    window.speechSynthesis.speak(utterance);
  }

  speakNext();
}

function chooseLanguage(lang, shouldScroll=true){selectedLang=lang;localStorage.setItem("rootcraftLang",lang);document.querySelectorAll(".language-card").forEach(c=>c.classList.toggle("active",c.dataset.lang===lang));portalTitle.textContent=`${DATA[lang].label} Learning`;portalSubtitle.textContent=DATA[lang].subtitle;renderTopics();renderStories();updateStats();if(shouldScroll)document.getElementById("learn").scrollIntoView({behavior:"smooth"})}
function renderTopics(filter=""){topicGrid.innerHTML="";Object.entries(DATA[selectedLang].topics).filter(([,t])=>t.title.toLowerCase().includes(filter.toLowerCase())).forEach(([key,t])=>{const b=document.createElement("button");b.className="topic-card";b.innerHTML=`<span>${t.icon}</span><h3>${t.title}</h3><p>Pictures, words and examples</p><small>${t.items.length} cards</small>`;b.onclick=()=>openLesson(key);topicGrid.appendChild(b)})}
function openLesson(key){topicGrid.classList.add("hidden");quizView.classList.add("hidden");lessonView.classList.remove("hidden");const t=DATA[selectedLang].topics[key];lessonTitle.textContent=t.title;lessonGrid.innerHTML="";t.items.forEach(([pic,word,meaning,example])=>{const c=document.createElement("article");c.className="lesson-card";const langClass=selectedLang==="kannada"?"kannada-text":selectedLang==="hindi"?"hindi-text":"";c.innerHTML=`<div class="pic">${pic}</div><div class="word ${langClass}">${word}</div><div class="meaning">${meaning}</div><div class="example ${langClass}">${example}</div><button class="listen-btn">🔊 Listen</button>`;c.querySelector("button").onclick=()=>{speak(word,meaning);progress.words[selectedLang]++;progress.stars[selectedLang]++;save();toast("⭐ Progress saved")};lessonGrid.appendChild(c)})}
function backHome(){lessonView.classList.add("hidden");quizView.classList.add("hidden");topicGrid.classList.remove("hidden")}
function pool(){return Object.values(DATA[selectedLang].topics).flatMap(t=>t.items)}
function shuffle(a){return [...a].sort(()=>Math.random()-.5)}
function startQuiz(){topicGrid.classList.add("hidden");lessonView.classList.add("hidden");quizView.classList.remove("hidden");currentQuiz=shuffle(pool()).slice(0,10);quizIndex=0;quizScore=0;renderQuiz();document.getElementById("learn").scrollIntoView({behavior:"smooth"})}
function renderQuiz(){const q=currentQuiz[quizIndex];quizPicture.textContent=q[0];quizScoreEl.textContent=`Score: ${quizScore}`;quizCount.textContent=`${quizIndex+1} / ${currentQuiz.length}`;quizMessage.textContent="";nextQuiz.classList.add("hidden");quizOptions.innerHTML="";const opts=shuffle([q[1],...shuffle(pool().map(i=>i[1]).filter(x=>x!==q[1])).slice(0,3)]);opts.forEach(o=>{const b=document.createElement("button");b.className="quiz-option";b.textContent=o;b.onclick=()=>checkQuiz(o,b,q);quizOptions.appendChild(b)})}
function checkQuiz(sel,b,q){[...document.querySelectorAll(".quiz-option")].forEach(x=>{x.disabled=true;if(x.textContent===q[1])x.classList.add("correct")});if(sel===q[1]){quizScore++;b.classList.add("correct");quizMessage.textContent="Correct! ⭐";progress.stars[selectedLang]+=2}else{b.classList.add("wrong");quizMessage.textContent=`Answer: ${q[1]}`}speak(q[1],q[2]);save();nextQuiz.classList.remove("hidden")}
function nextQ(){quizIndex++;if(quizIndex>=currentQuiz.length){progress.best[selectedLang]=Math.max(progress.best[selectedLang],quizScore);progress.stars[selectedLang]+=quizScore;save();quizView.querySelector(".quiz-box").innerHTML=`<div class="quiz-picture">🏆</div><h2>Quiz complete!</h2><p>You scored ${quizScore}/${currentQuiz.length}</p><button class="btn primary" onclick="location.reload()">Play Again</button>`}else renderQuiz()}
function playMemory(){memoryView.classList.remove("hidden");const pairs=shuffle(pool()).slice(0,6);const cards=shuffle(pairs.flatMap((i,n)=>[{id:n,v:i[0]},{id:n,v:i[1]}]));memoryBoard.innerHTML="";first=null;lock=false;cards.forEach(c=>{const b=document.createElement("button");b.className="memory-card";b.dataset.id=c.id;b.dataset.v=c.v;b.textContent="?";b.onclick=()=>flip(b);memoryBoard.appendChild(b)});memoryView.scrollIntoView({behavior:"smooth"})}
function flip(c){if(lock||c.classList.contains("matched")||c===first)return;c.classList.add("revealed");c.textContent=c.dataset.v;if(!first){first=c;return}if(first.dataset.id===c.dataset.id){first.classList.add("matched");c.classList.add("matched");progress.stars[selectedLang]+=3;save();first=null}else{lock=true;setTimeout(()=>{first.classList.remove("revealed");c.classList.remove("revealed");first.textContent="?";c.textContent="?";first=null;lock=false},700)}}
function renderStories(){storyGrid.innerHTML="";STORIES[selectedLang].forEach(([icon,title,text])=>{const a=document.createElement("article");a.className="story-card";a.innerHTML=`<span>${icon}</span><h3>${title}</h3><p>${text.slice(0,80)}...</p><button class="small-btn">Read Story</button>`;a.querySelector("button").onclick=()=>{currentStory={title,text};storyTitle.textContent=title;storyText.textContent=text;storyReader.classList.remove("hidden");storyReader.scrollIntoView({behavior:"smooth"})};storyGrid.appendChild(a)})}

document.addEventListener("DOMContentLoaded",()=>{ensure();year.textContent=new Date().getFullYear();loadVoices();if("speechSynthesis" in window)speechSynthesis.onvoiceschanged=loadVoices;
menuToggle.onclick=()=>mainNav.classList.toggle("open");document.querySelectorAll("nav a").forEach(a=>a.onclick=()=>mainNav.classList.remove("open"));
themeToggle.onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("rootcraftTheme",document.body.classList.contains("dark")?"dark":"light");themeToggle.textContent=document.body.classList.contains("dark")?"☀️":"🌙"};if(localStorage.getItem("rootcraftTheme")==="dark"){document.body.classList.add("dark");themeToggle.textContent="☀️"}
document.querySelectorAll(".language-card").forEach(c=>c.onclick=()=>chooseLanguage(c.dataset.lang,true));chooseLanguage(selectedLang,false);
searchInput.oninput=e=>renderTopics(e.target.value);backTopics.onclick=backHome;backQuiz.onclick=backHome;playQuiz.onclick=startQuiz;nextQuiz.onclick=nextQ;playMemory.onclick=playMemory;closeMemory.onclick=()=>memoryView.classList.add("hidden");showRewards.onclick=()=>toast(`🏆 ${progress.stars[selectedLang]} stars earned`);resetProgress.onclick=()=>{if(confirm("Reset progress for this language?")){progress.words[selectedLang]=0;progress.stars[selectedLang]=0;progress.best[selectedLang]=0;save();toast("Progress reset")}};closeStory.onclick=()=>{
  if("speechSynthesis" in window) window.speechSynthesis.cancel();
  storyReader.classList.add("hidden");
};
speakStory.onclick=()=>{
  if(!currentStory || !currentStory.text){
    toast("Open a story first.");
    return;
  }
  speak(currentStory.text,currentStory.text);
};
if("serviceWorker" in navigator){navigator.serviceWorker.getRegistrations().then(regs=>regs.forEach(r=>r.unregister()));}
});
